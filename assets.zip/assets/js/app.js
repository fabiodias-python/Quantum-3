particlesJS.load('particles-js', 'assets/js/particles-config.json', function() {
  console.log('particles.js loaded - callback');
});